

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card border border-primary">
            <div class="card-header bg-primary text-white"><h5 class="mt-2">Edit Data</h5></div>

                <div class="card-body">


                  <?php echo Form::model($appname, ['method'=>'PATCH', 'action'=> ['AdminController@update', $appname->id],'files'=>true]); ?>


                    <input type="hidden" name="last_url" value="<?php echo e(URL::previous()); ?>">

                      <div class="form-group mt-4">
                            <?php echo Form::label('app_name', 'App Name:'); ?>

                            <?php echo Form::text('app_name', null, ['class'=>'form-control border border-dark bg-white']); ?>

                      </div>

                      <div class="form-group">
                        <?php echo Form::submit('Update Data', ['class'=>'btn btn-success mt-3']); ?>

                      </div>

                  <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster\resources\views/admin/app/edit.blade.php ENDPATH**/ ?>