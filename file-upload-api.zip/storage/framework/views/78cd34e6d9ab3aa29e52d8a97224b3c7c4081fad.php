

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        App Add
        <!-- <small>Preview</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">App</a></li>
        <li class="active">Create</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- right column -->
        <div class="col-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Horizontal Form</h3> -->
            </div>
            <!-- /.box-header -->
            <!-- form start -->

    <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminAppdataController@store','files'=>true,'class'=>'form-horizontal']); ?>


    <?php echo csrf_field(); ?>

              <div class="box-body">
                <div class="form-group">
                  <label for="app_name" class="col-sm-2 control-label">App name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="app_name" id="app_name" placeholder="Enter App name" required>
                  </div>
                </div>

                <div class="form-group">
                  <label for="package_name" class="col-sm-2 control-label">Package Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="package_name" id="package_name" placeholder="Enter Package name" required>
                  </div>
                </div>

                <div class="form-group">
                  <label for="privacy" class="col-sm-2 control-label">Privacy Policy</label>
                  <div class="col-sm-10">
                    <input type="text" name="privacy" class="form-control" id="privacy" placeholder="Enter Privacy Policy">
                  </div>
                </div>
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default">Cancel</button> -->
                <!-- <button type="submit" class="btn btn-info">Sign in</button> -->
                <?php echo Form::submit('App Store', ['class'=>'btn btn-success text-white mt-1']); ?>

              </div>
              <!-- /.box-footer -->
        <?php echo Form::close(); ?>

          </div>
          <!-- /.box -->
          
         
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/appdata/create.blade.php ENDPATH**/ ?>