<?php
use App\Models\Appdata;
use App\Models\Adsdata;
?>

<?php $__env->startSection('style'); ?>
<style>
  b{
    color:#3095DB;
  }
  
</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Ads List
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Ads</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
            </div>

            <div class="row">

<div class="col-md-3" style="margin:10px 0;">

<a href="<?php echo e(route('admin.adsdata.create')); ?>" class="bg-primary text-white text-decoration-none" style="padding:12px 12px;margin-left:20px"><i class="mdi mdi-plus mdi-48px;"></i>&nbsp;ADD</a>

</div>

<div class="col-md-6" style="margin:15px 0;">

<div class="row text-center">
<?php echo e(Form::open(array('url' => '/searchapploginlink', 'name' => "frm_select_client"))); ?>

    <select id="client_id" name="appdata_id" onchange = "this.form.submit()" class="custom-select" style="width:70%">
    <option value="Select App">Select App Name</option>
        <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <option id="option-<?php echo e($app->id); ?>" value="<?php echo e($app->id); ?>"><?php echo e($app->app_name); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php echo Form::close(); ?>

</div>

</div>

<div class="col-md-2" style="margin:15px 0;">

  <!-- <form type="get" action="<?php echo e(url('/searchadsdata')); ?>" class="text-left mt-4">
        <div>
            <input type="text" name="query" class="border border-dark" placeholder="Search package name">
                <button type="submit" class="fa fa-search bg-primary text-white"></button>
        </div>
  </form> -->

  <form action="<?php echo e(url('/searchadsdata')); ?>" method="post" id="myForm">  

<input type="text" name="query" class="border border-dark" placeholder="Search package /app name">

</form>


</div>

<div class="col-md-1" style="margin:15px 0;">
<a href="/adsdata" class="btn btn-primary">Clear</a>
</div>

</div>



            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>Show</th>
                  <th>Action</th>
                  <th>Status</th>
                  <th>Screen</th>
                  <th>Package Information</th>
                  
                </tr>
                
                </thead>
                <tbody>
                
                <?php if($appnames->count()): ?>
              <?php $__currentLoopData = $appnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr> 
              <td>
                
<div class="float-end" style="margin-right:-50px">
<div id="animalstatus<?php echo e($appname->id); ?>" onclick="addappdata(this.id)" style="border:0px solid;"><i class="fa fa-plus-circle mt-2 text-primary" aria-hidden="true"></i>
</div>
</div>
               
                       
<div id="showsolddetailsanimalstatus<?php echo e($appname->id); ?>" style="display:none">

<b>Google</b><br/>
<b>Google App Id :</b><?php echo e($appname->googleappid); ?><br/>
<b>Google Medium Native:</b><?php echo e($appname->googlemediumnative); ?><br/>
<b>Google Interstitial:</b><?php echo e($appname->googleinterstitial); ?><br/>
<b>Google Banner:</b><?php echo e($appname->googlebanner); ?><br/>
<b>Google app open ads:</b><?php echo e($appname->googleappopenads); ?><br/>
<b>Google Reward:</b><?php echo e($appname->googlereward); ?><br/>
<b>Google Small Native:</b><?php echo e($appname->googlesmallnative); ?><br/>
-------------------------<br/>
<b>Applovin</b><br/>
<b>Applovin App Id:</b><?php echo e($appname->applovinappid); ?><br/>
<b>Applovin Medium Native:</b><?php echo e($appname->applovinmediumnative); ?><br/>
<b>Applovin Interstitial:</b><?php echo e($appname->applovininterstitial); ?><br/>
<b>Applovin Banner:</b><?php echo e($appname->applovinbanner); ?><br/>
<b>Applovin app open ads:</b><?php echo e($appname->applovinappopenads); ?><br/>
<b>Applovin Reward:</b><?php echo e($appname->applovinreward); ?><br/>
<b>Applovin Small Native:</b><?php echo e($appname->applovinsmallnative); ?><br/>
-------------------------<br/>
<b>Facebook</b><br/>
<b>Facebook App Id:</b><?php echo e($appname->facebookappid); ?><br/>
<b>Facebook Native:</b><?php echo e($appname->facebooknative); ?><br/>
<b>Facebook Interstitial:</b><?php echo e($appname->facebookinterstitial); ?><br/>
<b>Facebook Banner:</b><?php echo e($appname->facebookbanner); ?><br/>
<b>Facebook Native banner:</b><?php echo e($appname->facebooknativebanner); ?><br/>
<b>Facebook Medium rectangle:</b><?php echo e($appname->facebookmediumrectangle); ?><br/>
</div>

              </td>
<td>
  <a href="<?php echo e(route('admin.adsdata.edit', $appname->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:#0275d8;padding:8px;border-radius:200px;"></i></a>
  <a href="<?php echo e(route('admin.adsdata.destroy', $appname->id)); ?>"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:red;padding:8px;border-radius:200px;"></i></a>
</td>
                <!-- <td><?php echo e($appname->status); ?></td> -->
                <td>
                
    <?php echo Form::model($appname, ['method'=>'PATCH', 'action'=> ['AdminAdsdataController@update', $appname->id],'files'=>true,'class'=>'form-horizontal']); ?>


<?php echo csrf_field(); ?>
                  <select id="client_id" name="status" onchange = "this.form.submit()" class="custom-select">
                    <option style="display:none"><?php echo e($appname->status); ?></option>
                    <option value="0">0</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                  </select>
    <?php echo Form::close(); ?>


                </td>

                <td>
                
        <?php echo Form::model($appname, ['method'=>'PATCH', 'action'=> ['AdminAdsdataController@update', $appname->id],'files'=>true,'class'=>'form-horizontal']); ?>

    
    <?php echo csrf_field(); ?>
                      <select id="client_id" name="screen" onchange = "this.form.submit()" class="custom-select">
                        <option style="display:none"><?php echo e($appname->screen); ?></option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                      </select>
        <?php echo Form::close(); ?>

    
                  </td>


                <?php
                $data = Appdata::where('id',$appname->appdata_id)->first();
                ?>
                <td>
                <b>App Name : </b><?php echo e($data->app_name); ?><br/>
                <b>Package Name : </b><?php echo e($data->package_name); ?><br/>
                <b>Prvacy Policy : </b><?php echo e($data->privacy); ?><br/>
                <b>Redirect URL :</b><?php echo e($appname->redirect); ?><br/>
                  </td>

</tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

                </tbody>
              </table>

          <div class="row mt-4">

          <div class="col-sm-12 col-sm-offset-5" style="display:flex;justify-content:center;">

          <?php echo e($appnames->links('pagination::bootstrap-4')); ?>


          </div>
      </div>



            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
function addappdata(cli_id){
        // $("#showsolddetails"+cli_id).show();
  var div = document.getElementById("showsolddetails"+cli_id);
    if (div.style.display !== "block") {
        div.style.display = "block";
    }
    else {
        div.style.display = "none";
    }     
}
</script>

<script type="text/javascript">
var select = document.getElementById('client_id');
select.onchange = function(){
    this.form.submit();
};
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/adsdata/searchdata.blade.php ENDPATH**/ ?>