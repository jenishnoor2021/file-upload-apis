

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        App Edit
        <!-- <small>Preview</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">App</a></li>
        <li class="active">Edit</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- right column -->
        <div class="col-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Horizontal Form</h3> -->
            </div>
            <!-- /.box-header -->
            <!-- form start -->

            <?php echo Form::model($notes, ['method'=>'PATCH', 'action'=> ['AdminController@noteStore', $notes->id],'files'=>true]); ?>

<?php echo csrf_field(); ?>
                  
                  
<div class="form-group">
      <!-- <?php echo Form::label('body', 'notes:'); ?> -->
<textarea id="mytextarea" name="body"><?php echo e($notes->body); ?></textarea>
      <!-- <?php echo Form::textarea('body',null,['class'=>'form-control', 'rows' => 30, 'cols' => 100]); ?> -->
</div>

  <div class="form-group">
    <?php echo Form::submit('Save', ['class'=>'btn btn-success text-white mt-3']); ?>

  </div>

<?php echo Form::close(); ?>

          </div>
          <!-- /.box -->
          
         
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/note/edit.blade.php ENDPATH**/ ?>