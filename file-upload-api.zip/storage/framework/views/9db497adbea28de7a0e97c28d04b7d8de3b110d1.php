<table class="table table-bordered">
    <thead>
        <tr>
                <th>App id</th>
                  <th>App Name</th>
                  <th>Package Name</th>
                  <th>Privacy Policy</th>
                  <th>Edit</th>
                  <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        
    </tbody>
</table>
  



<?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/presult.blade.php ENDPATH**/ ?>