<?php
use App\Models\Appdata;
use App\Models\Adsdata;
?>



<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Ads create
        <!-- <small>Preview</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Ads</a></li>
        <li class="active">Create</li>
      </ol>
    </section>


<!-- Main content -->
<section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              
            </div>
            <!-- /.box-header -->

            <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminAdsdataController@store','files'=>true,'class'=>'form-horizontal']); ?>


<?php echo csrf_field(); ?>

          <div class="box-body">

            <div class="form-group">
              <label for="appdata_id" class="col-sm-2 control-label">App Data</label>
              <div class="col-sm-10">
              <select name="appdata_id" class="custom-select" style="width:100%" required>
              <option value="">Select App Name</option>
              <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$getdata = Adsdata::where('appdata_id',$app->id)->count();
?>
<?php if($getdata == 0): ?>
  <option value="<?php echo e($app->id); ?>"><?php echo e($app->app_name); ?></option>
 <?php else: ?>
 <option value="<?php echo e($app->id); ?>" disabled style="background-color:#e3e3e3"><?php echo e($app->app_name); ?></option>
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
              
<span id = "fnameMsg" style="color:red"> </span>
              </div>
            </div>

            <div class="box-body">
            <div class="form-group">
              <label for="status" class="col-sm-2 control-label">Status</label>
              <div class="col-sm-10">
              <?php echo Form::select('status', ['0'=>'0','1'=>'1','2'=>2,'3'=>'3'] , null, ['class'=>'form-control border border-dark text-dark mb-2','required' => 'required']); ?>

              </div>
            </div>

  <hr style="border:1px solid #000;"/>
    <p><b>Google Ads</b></p>
  <hr style="border:1px solid #000;"/>
            
            <div class="form-group">
              <label for="googleappid" class="col-sm-2 control-label">Google App Id</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googleappid" id="googleappid" placeholder="Enter Google App Id">
              </div>
            </div>

            <div class="form-group">
              <label for="googlemediumnative" class="col-sm-2 control-label">Google Medium Native</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googlemediumnative" id="googlemediumnative" placeholder="Enter Google Medium Native">
              </div>
            </div>

            <div class="form-group">
              <label for="googleinterstitial" class="col-sm-2 control-label">Google Interstitial</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googleinterstitial" id="googleinterstitial" placeholder="Enter Google Interstitial">
              </div>
            </div>

            <div class="form-group">
              <label for="googlebanner" class="col-sm-2 control-label">Google Banner</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googlebanner" id="googlebanner" placeholder="Enter Google Banner">
              </div>
            </div>

            <div class="form-group">
              <label for="googleappopenads" class="col-sm-2 control-label">Google app open ads</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googleappopenads" id="googleappopenads" placeholder="Enter Google app open ads">
              </div>
            </div>

            <div class="form-group">
              <label for="googlereward" class="col-sm-2 control-label">Google Reward</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googlereward" id="googlereward" placeholder="Enter Google Reward">
              </div>
            </div>

            <div class="form-group">
              <label for="googlesmallnative" class="col-sm-2 control-label">Google Small Native</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="googlesmallnative" id="googlesmallnative" placeholder="Enter Google Small Native">
              </div>
            </div>
            
<!-- applovin -->
<hr style="border:1px solid #000;"/>
    <p><b>Applovin Ads</b></p>
  <hr style="border:1px solid #000;"/>

<div class="form-group">
              <label for="applovinappid" class="col-sm-2 control-label">Applovin App Id
</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovinappid" id="applovinappid" placeholder="Enter Applovin App Id">
              </div>
            </div>

            <div class="form-group">
              <label for="applovinmediumnative" class="col-sm-2 control-label">Applovin Medium Native</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovinmediumnative" id="applovinmediumnative" placeholder="Enter Applovin Medium Native">
              </div>
            </div>

            <div class="form-group">
              <label for="applovininterstitial" class="col-sm-2 control-label">Applovin Interstitial</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovininterstitial" id="applovininterstitial" placeholder="Enter Applovin Interstitial">
              </div>
            </div>

            <div class="form-group">
              <label for="applovinbanner" class="col-sm-2 control-label">Applovin Banner</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovinbanner" id="applovinbanner" placeholder="Enter Applovin Banner">
              </div>
            </div>

            <div class="form-group">
              <label for="applovinappopenads" class="col-sm-2 control-label">Applovin app open ads</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovinappopenads" id="applovinappopenads" placeholder="Enter Applovin app open ads">
              </div>
            </div>

            <div class="form-group">
              <label for="applovinreward" class="col-sm-2 control-label">Applovin Reward</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovinreward" id="applovinreward" placeholder="Enter Applovin Reward">
              </div>
            </div>

            <div class="form-group">
              <label for="applovinsmallnative" class="col-sm-2 control-label">Applovin Small Native</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="applovinsmallnative" id="applovinsmallnative" placeholder="Enter Applovin Small Native">
              </div>
            </div>

<!-- end applovin -->

<hr style="border:1px solid #000;"/>
    <p><b>Facebook Ads</b></p>
  <hr style="border:1px solid #000;"/>
<!-- facebook -->

<div class="form-group">
              <label for="facebookappid" class="col-sm-2 control-label">Facebook App Id
</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="facebookappid" id="facebookappid" placeholder="Enter Facebook App Id">
              </div>
            </div>

            <div class="form-group">
              <label for="facebooknative" class="col-sm-2 control-label">Facebook Native</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="facebooknative" id="facebooknative" placeholder="Enter Facebook Native">
              </div>
            </div>

            <div class="form-group">
              <label for="facebookinterstitial" class="col-sm-2 control-label">Facebook Interstitial</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="facebookinterstitial" id="facebookinterstitial" placeholder="Enter Facebook Interstitial">
              </div>
            </div>

            <div class="form-group">
              <label for="facebookbanner" class="col-sm-2 control-label">Facebook Banner</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="facebookbanner" id="facebookbanner" placeholder="Enter Facebook Banner">
              </div>
            </div>

            <div class="form-group">
              <label for="facebooknativebanner" class="col-sm-2 control-label">Facebook Native banner</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="facebooknativebanner" id="facebooknativebanner" placeholder="Enter Facebook Native banner">
              </div>
            </div>

            <div class="form-group">
              <label for="facebookmediumrectangle" class="col-sm-2 control-label">Facebook Medium rectangle</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="facebookmediumrectangle" id="facebookmediumrectangle" placeholder="Enter Facebook Medium rectangle">
              </div>
            </div>

        
<!-- end facebook -->
<hr style="border:1px solid #000;"/>
    <p><b>Redirect URL</b></p>
  <hr style="border:1px solid #000;"/>

          <div class="form-group">
              <label for="redirect" class="col-sm-2 control-label">Redirect</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="redirect" id="redirect" placeholder="Enter Google App Id">
              </div>
            </div>

  <hr style="border:1px solid #000;"/>
    <p><b>Screen</b></p>
  <hr style="border:1px solid #000;"/>

            <div class="form-group">
              <label for="screen" class="col-sm-2 control-label">Screen Show</label>
              <div class="col-sm-10">
              <?php echo Form::select('screen', ['0'=>'0','1'=>'1','2'=>2,'3'=>'3','4'=>'4'] , null, ['class'=>'form-control border border-dark text-dark mb-2','required' => 'required']); ?>

              </div>
            </div>

<hr style="border:1px solid #000;"/>
  <p><b>Preload</b></p>
<hr style="border:1px solid #000;"/>

            <div class="form-group">
              <label for="status" class="col-sm-2 control-label">preload bannerapp</label>
              <div class="col-sm-10">
              <?php echo Form::select('preloadbannerapp', ['0'=>'0','1'=>'1'] , null, ['class'=>'form-control border border-dark text-dark mb-2','required' => 'required']); ?>

              </div>
            </div>

            <div class="form-group">
              <label for="status" class="col-sm-2 control-label">preload interstitial</label>
              <div class="col-sm-10">
              <?php echo Form::select('preloadinterstitial', ['0'=>'0','1'=>'1'] , null, ['class'=>'form-control border border-dark text-dark mb-2','required' => 'required']); ?>

              </div>
            </div>

            <div class="form-group">
              <label for="status" class="col-sm-2 control-label">preload nativ</label>
              <div class="col-sm-10">
              <?php echo Form::select('preloadnativ', ['0'=>'0','1'=>'1'] , null, ['class'=>'form-control border border-dark text-dark mb-2','required' => 'required']); ?>

              </div>
            </div>

            <div class="form-group">
              <label for="status" class="col-sm-2 control-label">preload reward</label>
              <div class="col-sm-10">
              <?php echo Form::select('preloadreward', ['0'=>'0','1'=>'1'] , null, ['class'=>'form-control border border-dark text-dark mb-2','required' => 'required']); ?>

              </div>
            </div>

          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <!-- <button type="submit" class="btn btn-default">Cancel</button> -->
            <!-- <button type="submit" class="btn btn-info">Sign in</button> -->
            <?php echo Form::submit('App Store', ['class'=>'btn btn-success text-white mt-1', "onclick"=>"thisform()"]); ?>

          </div>
          <!-- /.box-footer -->
    <?php echo Form::close(); ?>


            

            </div>
            <!-- /.box-body -->

        </div>
        <!--/.col (left) -->
        </div>

        <!-- right column -->
        <div class="col-md-4">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h1 class="box-title text-dark text-center"><b>Test id</b></h1>
            </div>
            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <hr style="border:1px solid #000;"/>
                <b>Google</b>
              <hr style="border:1px solid #000;"/>
            
            <b>Google App Id :</b><br/><pre><p><?php echo e($test->googleappid); ?></p></pre>
            <b>Google Medium Native:</b><br/><pre><p><?php echo e($test->googlemediumnative); ?></p></pre>
            <b>Google Interstitial:</b><br/><pre><p><?php echo e($test->googleinterstitial); ?></p></pre>
            <b>Google Banner:</b><br/><pre><p><?php echo e($test->googlebanner); ?></p></pre><br/>
            <b>Google app open ads:</b><br/><pre><p><?php echo e($test->googleappopenads); ?></p></pre>
            <b>Google Reward:</b><br/><pre><p><?php echo e($test->googlereward); ?></p></pre><br/>
            <b>Google Small Native:</b><br/><pre><p><?php echo e($test->googlesmallnative); ?></p></pre>
            <hr style="border:1px solid #000;"/>
                <b>Applovin</b>
              <hr style="border:1px solid #000;"/>

            <b>Applovin App Id:</b><br/><pre><p><?php echo e($test->applovinappid); ?></p></pre>
            <b>Applovin Medium Native:</b><br/><pre><p><?php echo e($test->applovinmediumnative); ?></p></pre>
            <b>Applovin Interstitial:</b><br/><pre><p><?php echo e($test->applovininterstitial); ?></p></pre>
            <b>Applovin Banner:</b><br/><pre><p><?php echo e($test->applovinbanner); ?></p></pre><br/>
            <b>Applovin app open ads:</b><br/><pre><p><?php echo e($test->applovinappopenads); ?></p></pre>
            <b>Applovin Reward:</b><br/><pre><p><?php echo e($test->applovinreward); ?></p></pre><br/>
            <b>Applovin Small Native:</b><br/><pre><p><?php echo e($test->applovinsmallnative); ?></p></pre>

            <hr style="border:1px solid #000;"/>
                <b>Facebook</b>
              <hr style="border:1px solid #000;"/>
            <b>Facebook App Id:</b><br/><pre><p><?php echo e($test->facebookappid); ?></p></pre>
            <b>Facebook Native:</b><br/><pre><p><?php echo e($test->facebooknative); ?></p></pre>
            <b>Facebook Interstitial:</b><br/><pre><p><?php echo e($test->facebookinterstitial); ?></p></pre>
            <b>Facebook Banner:</b><br/><pre><p><?php echo e($test->facebookbanner); ?></p></pre>
            <b>Facebook Native banner:</b><br/><pre><p><?php echo e($test->facebooknativebanner); ?></p></pre>
            <b>Facebook Medium rectangle:</b><br/><pre><p><?php echo e($test->facebookmediumrectangle); ?></p></pre>
            <hr style="border:1px solid #000;"/>
            <b>Gamezop:</b><br/><pre><p><?php echo e($test->gamezope); ?></p></pre>
            <b>Atmi:</b><br/><pre><p><?php echo e($test->atmi); ?></p></pre>
            <b>Quereka:</b><br/><pre><p><?php echo e($test->qureka); ?></p></pre>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($testext)>0): ?>
            <hr style="border:1px solid #000;"/>
                <b>Extra test id</b>
              <hr style="border:1px solid #000;"/>
            <?php $__currentLoopData = $testext; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <b><?php echo e($teste->title); ?>:</b><br/><pre><p><?php echo e($teste->body); ?></p></pre>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

  </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/adsdata/create.blade.php ENDPATH**/ ?>