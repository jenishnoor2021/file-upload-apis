<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin</title>
  <!-- plugins:css -->
  <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/base/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" />

<style>
  .back-img{
    background:linear-gradient( rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6) ),url("<?php echo e(asset('/images/back5.jpg')); ?>");  
    background-repeat: no-repeat;
    background-position: center; /* Center the image */
    background-size: cover; /* Resize the background image to cover the entire container */
    height:100vh;
    padding-top:100px;
  }
  .container-scrolle {
    background: white;
    margin: auto auto;
    padding: 10px 40px;
    border-radius: 25px;
    color: black;
    box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);
}

</style>


</head>

<body>

<div class="back-img">

<div class="row justify-content-center">
    <div class="col-xl-3 col-md-6 col-sm-12">

  <div class="container-scrolle">
    
        <div class="brand-logo">
          <img src="<?php echo e(asset('images/admin-logo.png')); ?>" height="130px;" width="100%" alt="logo">
        </div>
              
              <form action="<?php echo e(route('login')); ?>" method="POST" class="pt-2">

                <div class="form-group">
                    <?php echo csrf_field(); ?>
                    <label for="exampleInputEmail1">Username</label>
                    <div class="input-group border border-dark">
                      <div class="input-group-addon" style="margin-top:10px;margin-left:10px;margin-right:10px;">
                      <i class="fas fa-user-alt text-primary fas-24px"></i>
                      </div>
                      <input type="text" name="username" class="form-control form-control-lg" required="" id="exampleInputEmail1" placeholder="Username"> 
                    </div>
                </div>

                <div class="form-group">
                <label for="floatingPassword">Password</label>
                  <div class="input-group border border-dark">
                      <div class="input-group-addon" style="margin-top:10px;margin-left:10px;margin-right:10px;">
                      <i class="fas fa-lock text-primary fas-24px"></i>
                      </div>
                      <input type="password" name="password" class="form-control form-control-lg" required="" id="exampleInputPassword1" placeholder="Password"> 
                    </div>
                </div>

                <div class="text-center">
                <button type="submit" class="btn btn-primary text-white py-3 w-100 mb-4">Sign In</button>
                </div>
            </form>
            
          </div>
</div>
              
    </div>

</div>


  <script src="<?php echo e(asset('vendors/base/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('js/template.js')); ?>"></script>
  <!-- endinject -->
</body>

</html><?php /**PATH E:\API\Tour-apis\admin_panel_after-image-compress\resources\views/auth/login.blade.php ENDPATH**/ ?>