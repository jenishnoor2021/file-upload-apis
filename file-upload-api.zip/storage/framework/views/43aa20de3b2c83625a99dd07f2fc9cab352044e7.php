

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Test
        <!-- <small>Preview</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">test</a></li>
        <li class="active">Create</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- right column -->
        <div class="col-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Horizontal Form</h3> -->
            </div>
            <!-- /.box-header -->
            <!-- form start -->

    <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminTestController@store','files'=>true,'class'=>'form-horizontal']); ?>


    <?php echo csrf_field(); ?>

              <div class="box-body">
                                
                <div class="form-group">
                  <label for="googleappid" class="col-sm-2 control-label">Google App Id</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googleappid" id="googleappid" placeholder="Enter Google App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlemediumnative" class="col-sm-2 control-label">Google Medium Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlemediumnative" id="googlemediumnative" placeholder="Enter Google Medium Native">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googleinterstitial" class="col-sm-2 control-label">Google Interstitial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googleinterstitial" id="googleinterstitial" placeholder="Enter Google Interstitial">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlebanner" class="col-sm-2 control-label">Google Banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlebanner" id="googlebanner" placeholder="Enter Google Banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googleappopenads" class="col-sm-2 control-label">Google app open ads</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googleappopenads" id="googleappopenads" placeholder="Enter Google app open ads">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlereward" class="col-sm-2 control-label">Google Reward</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlereward" id="googlereward" placeholder="Enter Google Reward">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlesmallnative" class="col-sm-2 control-label">Google Small Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlesmallnative" id="googlesmallnative" placeholder="Enter Google Small Native">
                  </div>
                </div>
                
<!-- applovin -->

<div class="form-group">
                  <label for="applovinappid" class="col-sm-2 control-label">Applovin App Id
</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinappid" id="applovinappid" placeholder="Enter Applovin App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinmediumnative" class="col-sm-2 control-label">Applovin Medium Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinmediumnative" id="applovinmediumnative" placeholder="Enter Applovin Medium Native">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovininterstitial" class="col-sm-2 control-label">Applovin Interstitial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovininterstitial" id="applovininterstitial" placeholder="Enter Applovin Interstitial">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinbanner" class="col-sm-2 control-label">Applovin Banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinbanner" id="applovinbanner" placeholder="Enter Applovin Banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinappopenads" class="col-sm-2 control-label">Applovin app open ads</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinappopenads" id="applovinappopenads" placeholder="Enter Applovin app open ads">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinreward" class="col-sm-2 control-label">Applovin Reward</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinreward" id="applovinreward" placeholder="Enter Applovin Reward">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinsmallnative" class="col-sm-2 control-label">Applovin Small Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinsmallnative" id="applovinsmallnative" placeholder="Enter Applovin Small Native">
                  </div>
                </div>

<!-- end applovin -->

<!-- facebook -->

<div class="form-group">
                  <label for="facebookappid" class="col-sm-2 control-label">Facebook App Id
</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookappid" id="facebookappid" placeholder="Enter Facebook App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebooknative" class="col-sm-2 control-label">Facebook Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebooknative" id="facebooknative" placeholder="Enter Facebook Native">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebookinterstitial" class="col-sm-2 control-label">Facebook Interstitial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookinterstitial" id="facebookinterstitial" placeholder="Enter Facebook Interstitial">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebookbanner" class="col-sm-2 control-label">Facebook Banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookbanner" id="facebookbanner" placeholder="Enter Facebook Banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebooknativebanner" class="col-sm-2 control-label">Facebook Native banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebooknativebanner" id="facebooknativebanner" placeholder="Enter Facebook Native banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebookmediumrectangle" class="col-sm-2 control-label">Facebook Medium rectangle</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookmediumrectangle" id="facebookmediumrectangle" placeholder="Enter Facebook Medium rectangle">
                  </div>
                </div>

            
<!-- end facebook -->

<div class="form-group">
                  <label for="gamezope" class="col-sm-2 control-label">Gamezope</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="gamezope" id="gamezope" placeholder="Enter Google App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="atmi" class="col-sm-2 control-label">Atmi</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="atmi" id="atmi" placeholder="Enter Google App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="qureka" class="col-sm-2 control-label">Quereka</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="qureka" id="qureka" placeholder="Enter Google App Id">
                  </div>
                </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default">Cancel</button> -->
                <!-- <button type="submit" class="btn btn-info">Sign in</button> -->
                <?php echo Form::submit('Store Test id', ['class'=>'btn btn-success text-white mt-1']); ?>

              </div>
              <!-- /.box-footer -->
        <?php echo Form::close(); ?>

          </div>
          <!-- /.box -->
          
         
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/test/create.blade.php ENDPATH**/ ?>