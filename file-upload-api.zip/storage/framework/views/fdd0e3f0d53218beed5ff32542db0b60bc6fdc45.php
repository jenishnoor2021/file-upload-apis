

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11 mt-4">
            <div class="card border border-primary">
                <div class="card-header bg-primary text-white"><h5 class="mt-2">ADD Ads</h5></div>

                <div class="card-body">
                    

                          <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminLinksController@store','files'=>true]); ?>

                   

                            <div class="form-group">
                                  <?php echo Form::label('ads_name', 'Ads Name:'); ?>

                                  <?php echo Form::text('ads_name', null, ['class'=>'form-control border border-dark mb-2','required' => 'required']); ?>

                            </div>

                            <div class="form-group">
                                  <?php echo Form::label('ads_status', 'Status:'); ?>

                                  <?php echo Form::select('ads_status', array('0' => '0', '1' => '1') , null, ['class'=>'form-control border border-dark text-dark mb-2']); ?>

                            </div>

                            <div class="form-group">
                                  <?php echo Form::label('ads_link', 'Link:'); ?>

                                  <?php echo Form::textarea('ads_link', null, ['class'=>'form-control border border-dark bg-white mb-2','rows' => 4, 'cols' => 30,'required' => 'required']); ?>

                            </div>

                            <div class="form-group">
                              <?php echo Form::submit('Add Data', ['class'=>'btn btn-success text-white mt-3']); ?>

                            </div>

                            <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster_third\resources\views/admin/ads/create.blade.php ENDPATH**/ ?>