

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border border-primary">
                <div class="card-header bg-primary text-white"><h5 class="mt-2">List of App</h5></div>
                
                <div class="card-body">

<a href="<?php echo e(route('admin.app.create')); ?>" class="bg-primary text-white text-decoration-none" style="padding:8px 8px;"><i class="mdi mdi-plus mdi-48px;"></i>&nbsp;ADD</a>

<button style="padding:10px 10px;" class="btn btn-danger mb-1 text-white delete_all" data-url="<?php echo e(url('myappsDeleteAll')); ?>">Delete</button>

<div class="float-end">
<input type="text" class="form-controller border-dark mt-4" id="search" name="search" placeholder="Search"><i class="mdi mdi-search-web bg-primary text-white p-1"></i></input>

</div>


<table class="table border border-dark mt-4 table-striped">
          <thead style="text-align:center;">
              <tr>              
                    <th width="50px" class="border border-dark"><input type="checkbox" id="master"></th>                   
                  <th class="border border-dark">APP_ID</th>
                  <th class="border border-dark">App_name</th>
                  <th class="border border-dark">create data</th>
                  <th class="border border-dark">Edit</th>
                  <th class="border border-dark">Delete</th>
              </tr>
              </thead>
              <tbody style="text-align:center;">

      <?php if($appnames->count()): ?>
              <?php $__currentLoopData = $appnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr id="tr_<?php echo e($appname->id); ?>"> 
                    
              <td style="text-align:center;"><input type="checkbox" class="sub_chk" data-id="<?php echo e($appname->id); ?>"></td>
                      <td class="border border-dark"><?php echo e($appname->id); ?></td>
                      <td class="border border-dark"><?php echo e($appname->app_name); ?></td>
                      <td class="border border-dark"><?php echo e($appname->created_at->format('d/m/Y')); ?></td>
                      <td class="border border-dark"><a href="<?php echo e(route('admin.app.edit', $appname->id)); ?>"><i class='mdi mdi-account-edit' style="color:white;font-size:20px;background-color:#0275d8;padding:5px;"></i></a></td>
                      <td class="border border-dark">
                          <?php echo Form::open(['method'=>'GET', 'action'=> ['AdminController@destroy', $appname->id]]); ?>

                          
                              <?php echo Form::button('<i class="mdi mdi-delete" style="color:white;font-size:20px;background-color:red;padding:5px;"></i>', ['class'=>'btn', 'role' => 'button', 'type' => 'submit']); ?>

                          
                          <?php echo Form::close(); ?>  
                      </td>
                          
                  </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          </tbody>
          </table>

      <div class="row mt-4">

          <div class="col-sm-12 col-sm-offset-5" style="display:flex;justify-content:center;">

          <?php echo e($appnames->links('pagination::bootstrap-4')); ?>


          </div>
      </div>

              </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster\resources\views/admin/app/index.blade.php ENDPATH**/ ?>