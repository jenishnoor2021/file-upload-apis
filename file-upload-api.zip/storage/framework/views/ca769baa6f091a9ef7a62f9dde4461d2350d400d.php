

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border border-primary">
                <div class="card-header bg-primary text-white"><h5 class="mt-2">Edit Data</h5></div>

                <div class="card-body">
                  
                  <?php echo Form::model($adslink, ['method'=>'PATCH', 'action'=> ['AdminLinksController@update', $adslink->id],'files'=>true]); ?>

                  
                  <input type="hidden" name="last_url" value="<?php echo e(URL::previous()); ?>">

                        <div class="form-group">
                              <?php echo Form::label('app_id', 'App Name:'); ?>

                              <?php echo Form::select('app_id', $apps , null, ['class'=>'form-control border border-dark mb-2 text-dark']); ?>

                          </div>                      

                            <div class="form-group">
                                  <?php echo Form::label('ads_name', 'Ads Name:'); ?>

                                  <?php echo Form::text('ads_name', null, ['class'=>'form-control border border-dark mb-2']); ?>

                            </div>

                            <div class="form-group">
                              <?php echo Form::label('ads_status', 'Status:'); ?>

                              <?php echo Form::select('ads_status', array('0' => '0', '1' => '1') , null, ['class'=>'form-control border border-dark mb-2 text-dark']); ?>

                          </div>  

                            <div class="form-group">
                                  <?php echo Form::label('ads_link', 'Link:'); ?>

                                  <?php echo Form::text('ads_link', null, ['class'=>'form-control border border-dark mb-2']); ?>

                            </div>

                            <div class="form-group">
                              <?php echo Form::submit('Update Data', ['class'=>'btn btn-success text-white mt-3']); ?>

                            </div>

                            <?php echo Form::close(); ?>

 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster\resources\views/admin/ads/edit.blade.php ENDPATH**/ ?>