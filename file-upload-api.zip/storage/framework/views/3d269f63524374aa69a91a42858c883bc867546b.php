<?php
use App\Models\testextra;
?>




<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Test data
        <!-- <small>Preview</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Test</a></li>
        <li class="active">Edit</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- right column -->
        <div class="col-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Horizontal Form</h3> -->
            </div>
            <!-- /.box-header -->
            <!-- form start -->

  <?php echo Form::model($appname, ['method'=>'PATCH', 'action'=> ['AdminTestController@update', $appname->id],'files'=>true,'class'=>'form-horizontal']); ?>


    <?php echo csrf_field(); ?>

              <div class="box-body">

    <hr style="border:1px solid #000;"/>
    <p><b>Google Ads</b></p>
  <hr style="border:1px solid #000;"/>


              <div class="form-group">
                  <label for="googleappid" class="col-sm-2 control-label">Google App Id</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googleappid" id="googleappid" value="<?php echo e($appname->googleappid); ?>" placeholder="Enter Google App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlemediumnative" class="col-sm-2 control-label">Google Medium Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlemediumnative" id="googlemediumnative" value="<?php echo e($appname->googlemediumnative); ?>" placeholder="Enter Google Medium Native">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googleinterstitial" class="col-sm-2 control-label">Google Interstitial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googleinterstitial" id="googleinterstitial" value="<?php echo e($appname->googleinterstitial); ?>" placeholder="Enter Google Interstitial">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlebanner" class="col-sm-2 control-label">Google Banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlebanner" id="googlebanner" value="<?php echo e($appname->googlebanner); ?>" placeholder="Enter Google Banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googleappopenads" class="col-sm-2 control-label">Google app open ads</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googleappopenads" id="googleappopenads" value="<?php echo e($appname->googleappopenads); ?>" placeholder="Enter Google app open ads">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlereward" class="col-sm-2 control-label">Google Reward</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlereward" id="googlereward" value="<?php echo e($appname->googlereward); ?>" placeholder="Enter Google Reward">
                  </div>
                </div>

                <div class="form-group">
                  <label for="googlesmallnative" class="col-sm-2 control-label">Google Small Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="googlesmallnative" id="googlesmallnative" value="<?php echo e($appname->googlesmallnative); ?>" placeholder="Enter Google Small Native">
                  </div>
                </div>
                
<!-- applovin -->

<hr style="border:1px solid #000;"/>
    <p><b>Applovin Ads</b></p>
  <hr style="border:1px solid #000;"/>

<div class="form-group">
                  <label for="applovinappid" class="col-sm-2 control-label">Applovin App Id
</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinappid" id="applovinappid" value="<?php echo e($appname->applovinappid); ?>" placeholder="Enter Applovin App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinmediumnative" class="col-sm-2 control-label">Applovin Medium Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinmediumnative" id="applovinmediumnative" value="<?php echo e($appname->applovinmediumnative); ?>" placeholder="Enter Applovin Medium Native">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovininterstitial" class="col-sm-2 control-label">Applovin Interstitial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovininterstitial" id="applovininterstitial" value="<?php echo e($appname->applovininterstitial); ?>" placeholder="Enter Applovin Interstitial">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinbanner" class="col-sm-2 control-label">Applovin Banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinbanner" id="applovinbanner" value="<?php echo e($appname->applovinbanner); ?>" placeholder="Enter Applovin Banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinappopenads" class="col-sm-2 control-label">Applovin app open ads</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinappopenads" id="applovinappopenads" value="<?php echo e($appname->applovinappopenads); ?>" placeholder="Enter Applovin app open ads">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinreward" class="col-sm-2 control-label">Applovin Reward</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinreward" id="applovinreward" value="<?php echo e($appname->applovinreward); ?>" placeholder="Enter Applovin Reward">
                  </div>
                </div>

                <div class="form-group">
                  <label for="applovinsmallnative" class="col-sm-2 control-label">Applovin Small Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="applovinsmallnative" id="applovinsmallnative" value="<?php echo e($appname->applovinsmallnative); ?>" placeholder="Enter Applovin Small Native">
                  </div>
                </div>

<!-- end applovin -->
<hr style="border:1px solid #000;"/>
    <p><b>Facebook Ads</b></p>
  <hr style="border:1px solid #000;"/>
<!-- facebook -->

<div class="form-group">
                  <label for="facebookappid" class="col-sm-2 control-label">Facebook App Id
</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookappid" id="facebookappid" value="<?php echo e($appname->facebookappid); ?>" placeholder="Enter Facebook App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebooknative" class="col-sm-2 control-label">Facebook Native</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebooknative" id="facebooknative" value="<?php echo e($appname->facebooknative); ?>" placeholder="Enter Facebook Native">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebookinterstitial" class="col-sm-2 control-label">Facebook Interstitial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookinterstitial" id="facebookinterstitial" value="<?php echo e($appname->facebookinterstitial); ?>" placeholder="Enter Facebook Interstitial">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebookbanner" class="col-sm-2 control-label">Facebook Banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookbanner" id="facebookbanner" value="<?php echo e($appname->facebookbanner); ?>" placeholder="Enter Facebook Banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebooknativebanner" class="col-sm-2 control-label">Facebook Native banner</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebooknativebanner" id="facebooknativebanner" value="<?php echo e($appname->facebooknativebanner); ?>" placeholder="Enter Facebook Native banner">
                  </div>
                </div>

                <div class="form-group">
                  <label for="facebookmediumrectangle" class="col-sm-2 control-label">Facebook Medium rectangle</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebookmediumrectangle" id="facebookmediumrectangle" value="<?php echo e($appname->facebookmediumrectangle); ?>" placeholder="Enter Facebook Medium rectangle">
                  </div>
                </div>

            
<!-- end facebook -->

<hr style="border:1px solid #000;"/>
    <p><b>Other Ads ids</b></p>
  <hr style="border:1px solid #000;"/>

<div class="form-group">
                  <label for="gamezope" class="col-sm-2 control-label">Gamezope</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="gamezope" id="gamezope" value="<?php echo e($appname->gamezope); ?>" placeholder="Enter Google App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="atmi" class="col-sm-2 control-label">Atmi</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="atmi" id="atmi" value="<?php echo e($appname->atmi); ?>" placeholder="Enter Google App Id">
                  </div>
                </div>

                <div class="form-group">
                  <label for="qureka" class="col-sm-2 control-label">Quereka</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="qureka" id="qureka" value="<?php echo e($appname->qureka); ?>" placeholder="Enter Google App Id">
                  </div>
                </div>
                
<?php
$datagetnew = testextra::count();
$getdatas = testextra::get();
?>

<?php if($datagetnew == 0): ?>

<?php else: ?>

<?php $__currentLoopData = $getdatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="form-group">
  <label for="qureka" class="col-sm-2 control-label"><?php echo e($getdata->title); ?></label>
  <div class="col-sm-10">
  <!-- <?php echo e($getdata->body); ?> -->
  <input value="<?php echo e($getdata->body); ?>" style="width:80%" placeholder="Enter App Id">
  <button type="button" id="animalstatus<?php echo e($getdata->id); ?>" onclick="addappdataedit(this.id)" style="border:none;padding:5px;border-radius:200px;background-color:blue;"><i class="fa fa-edit fa-1x bg-primary text-white"></i></button>
  <!-- <a href="<?php echo e(route('admin.addtestid.edit', $getdata->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:blue;padding:8px;border-radius:200px;"></i></a> -->
  <a href="<?php echo e(route('admin.addtestid.destroy', $getdata->id)); ?>"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:red;padding:8px;border-radius:200px;"></i></a>

    <!-- <input type="text" class="form-control" name="qureka" id="qureka" value="<?php echo e($getdata->body); ?>" placeholder="Enter Google App Id"> -->


  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-10">
<button type="button" id="animalstatus" onclick="addappdata(this.id)" style="border:none;padding:10px;"><i class="fa fa-plus fa-2x bg-primary text-white"></i></button>
</div>
</div>


              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default">Cancel</button> -->
                <!-- <button type="submit" class="btn btn-info">Sign in</button> -->
                <?php echo Form::submit('Update Data', ['class'=>'btn btn-success text-white mt-1']); ?>

              </div>
              <!-- /.box-footer -->
        <?php echo Form::close(); ?>


        

  <?php echo Form::open(['method'=>'POST', 'action'=> 'ApiLinksController@store','files'=>true]); ?>


<?php echo csrf_field(); ?>
        <div class="row mt-2" id="showsolddetailsanimalstatus" style="display:none;margin:20px 10px;">
            <div class="form-group col-md-2">
                <?php echo Form::label('title', 'Title', ['class'=>'text-normal']); ?>

                <?php echo Form::text('title',  null, ['class'=>'form-control shadow-dark','required'=>'required']); ?>

            </div>

            <div class="form-group col-md-4">
            <?php echo Form::label('body', 'Data', ['class'=>'text-normal']); ?>

          <?php echo Form::text('body', null, ['class'=>'form-control shadow-dark']); ?>

          
            </div>

          <div class="form-group col-md-2">
              <?php echo Form::submit('ADD', ['class'=>'btn text-white btn-primary']); ?>

          </div>

        </div>

<?php echo Form::close(); ?>



<?php
$datagetnew = testextra::count();
$getdatas = testextra::get();
?>

<?php if($datagetnew != 0): ?>

<?php $__currentLoopData = $getdatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo Form::model($getdata, ['method'=>'PATCH', 'action'=> ['ApiLinksController@update', $getdata->id],'files'=>true,'class'=>'form-horizontal']); ?>


    <?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($getdata->id); ?>">
  
        <div class="row mt-2" id="showsolddetailseditanimalstatus<?php echo e($getdata->id); ?>" style="display:none;margin:20px 10px;">
          <div class="form-group col-md-10">
            
          <?php echo Form::text('body', null, ['class'=>'form-control shadow-dark']); ?>

          
            </div>

          <div class="form-group col-md-2">
              <?php echo Form::submit('update', ['class'=>'btn text-white btn-primary']); ?>

          </div>

        </div>

<?php echo Form::close(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

          </div>
          <!-- /.box -->
          
         
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script type="text/javascript">
// Hide the extra content initially, using JS so that if JS is disabled, no problemo:
            $('.read-more-content').addClass('hide_content')
            $('.read-more-show, .read-more-hide').removeClass('hide_content')

            // Set up the toggle effect:
            $('.read-more-show').on('click', function(e) {
              $(this).next('.read-more-content').removeClass('hide_content');
              $(this).addClass('hide_content');
              e.preventDefault();
            });

            // Changes contributed by @diego-rzg
            $('.read-more-hide').on('click', function(e) {
              var p = $(this).parent('.read-more-content');
              p.addClass('hide_content');
              p.prev('.read-more-show').removeClass('hide_content'); // Hide only the preceding "Read More"
              e.preventDefault();
            });
</script>

<script>
function addappdata(cli_id){
        $("#showsolddetails"+cli_id).show();     
    }

    function addappdataedit(cli_id){
        $("#showsolddetailsedit"+cli_id).show();     
    }
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/test/edit.blade.php ENDPATH**/ ?>