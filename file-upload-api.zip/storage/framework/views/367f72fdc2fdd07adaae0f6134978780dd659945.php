<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>New Admin Dashboard</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/base/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" />

<style>
  .back-img{
    background:linear-gradient( rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6) ),url("<?php echo e(asset('/images/back5.jpg')); ?>");  
    background-repeat: no-repeat;
    background-position: center; /* Center the image */
    background-size: cover; /* Resize the background image to cover the entire container */
    height:100vh;
    padding-top:100px;
  }
  .container-scrolle {
    background: white;
    width: 25%;
    /* margin-top: 100px;
    margin-bottom: 100px; */
    margin: auto auto;
    padding: 10px 40px;
    border-radius: 25px;
    color: black;
    box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);
}

</style>


</head>

<body>

<div class="back-img">

  <div class="container-scrolle">
    
        <div class="brand-logo">
          <img src="<?php echo e(asset('images/admin-logo.png')); ?>" height="130px;" width="100%" alt="logo">
        </div>
              
              <form action="<?php echo e(route('login')); ?>" method="POST" class="pt-2">

                <div class="form-group">
                    <?php echo csrf_field(); ?>
                    <label for="exampleInputEmail1">Username</label>
                    <div class="input-group border border-dark">
                      <div class="input-group-addon" style="margin-top:7px;margin-left:10px;">
                      <i class="mdi mdi-account text-primary mdi-24px"></i>
                      </div>
                      <input type="text" name="username" class="form-control form-control-lg" required="" id="exampleInputEmail1" placeholder="Username"> 
                    </div>
                </div>

                <div class="form-group">
                <label for="floatingPassword">Password</label>
                  <div class="input-group border border-dark">
                      <div class="input-group-addon" style="margin-top:7px;margin-left:10px;">
                      <i class="mdi mdi-lock text-primary mdi-24px"></i>
                      </div>
                      <input type="password" name="password" class="form-control form-control-lg" required="" id="exampleInputPassword1" placeholder="Password"> 
                    </div>
                </div>

                <div class="text-center">
                <button type="submit" class="btn btn-primary text-white py-3 w-100 mb-4">Sign In</button>
                </div>
            </form>

              
    </div>

</div>


  <script src="<?php echo e(asset('vendors/base/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('js/template.js')); ?>"></script>
  <!-- endinject -->
</body>

</html><?php /**PATH E:\API\admin_panel_after-image-compress\ADMIN_PANEL_FINAL_ALL_API_MAKE_USE_THIS\resources\views/auth/login.blade.php ENDPATH**/ ?>