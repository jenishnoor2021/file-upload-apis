

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Test
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">test</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
            </div>

<!-- <a href="<?php echo e(route('admin.test.create')); ?>" class="bg-primary text-white text-decoration-none" style="padding:12px 12px;margin-left:20px"><i class="mdi mdi-plus mdi-48px;"></i>&nbsp;ADD</a> -->

            <!-- /.box-header -->
            <div class="box-body" style="overflow-x:auto;">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Google</th>
                  <th>Applovin</th>
                  <th>Facebook</th>
                  <th>Gamezop</th>
                  <th>Atmi</th>
                  <th>Quereka</th>
                  <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                
              <?php $__currentLoopData = $appnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <td>
                <span class="boldclass">Google App Id :</span><?php echo e($appname->googleappid); ?><br/>
                <span class="boldclass">Google Medium Native:</span><?php echo e($appname->googlemediumnative); ?><br/>
                <span class="boldclass">Google Interstitial:</span><?php echo e($appname->googleinterstitial); ?><br/>
                <span class="boldclass">Google Banner:</span><?php echo e($appname->googlebanner); ?><br/>
                <span class="boldclass">Google app open ads:</span><?php echo e($appname->googleappopenads); ?><br/>
                <span class="boldclass">Google Reward:</span><?php echo e($appname->googlereward); ?><br/>
                <span class="boldclass">Google Small Native:</span><?php echo e($appname->googlesmallnative); ?><br/>
               </td>
               <td>
               <span class="boldclass">Applovin App Id:</span><?php echo e($appname->applovinappid); ?><br/>
               <span class="boldclass">Applovin Medium Native:</span><?php echo e($appname->applovinmediumnative); ?><br/>
               <span class="boldclass">Applovin Interstitial:</span><?php echo e($appname->applovininterstitial); ?><br/>
               <span class="boldclass">Applovin Banner:</span><?php echo e($appname->applovinbanner); ?><br/>
               <span class="boldclass">Applovin app open ads:</span><?php echo e($appname->applovinappopenads); ?><br/>
               <span class="boldclass">Applovin Reward:</span><?php echo e($appname->applovinreward); ?><br/>
               <span class="boldclass">Applovin Small Native:</span><?php echo e($appname->applovinsmallnative); ?><br/>
               </td>
               <td>
               <span class="boldclass">Facebook App Id:</span><?php echo e($appname->facebookappid); ?><br/>
               <span class="boldclass">Facebook Native:</span><?php echo e($appname->facebooknative); ?><br/>
               <span class="boldclass">Facebook Interstitial:</span><?php echo e($appname->facebookinterstitial); ?><br/>
               <span class="boldclass">Facebook Banner:</span><?php echo e($appname->facebookbanner); ?><br/>
               <span class="boldclass">Facebook Native banner:</span><?php echo e($appname->facebooknativebanner); ?><br/>
               <span class="boldclass">Facebook Medium rectangle:</span><?php echo e($appname->facebookmediumrectangle); ?><br/>
               </td>
               <td><?php echo e($appname->gamezope); ?></td>
               <td><?php echo e($appname->atmi); ?></td>
               <td><?php echo e($appname->qureka); ?></td>
               <td><a href="<?php echo e(route('admin.test.edit', $appname->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:20px;background-color:#0275d8;padding:5px;"></i></a></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
function addappdata(cli_id){
        // $("#showsolddetails"+cli_id).show();
  var div = document.getElementById("showsolddetails"+cli_id);
    if (div.style.display !== "block") {
        div.style.display = "block";
    }
    else {
        div.style.display = "none";
    }     
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/test/index.blade.php ENDPATH**/ ?>