<?php
use Ladumor\OneSignal\OneSignal;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>New Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/base/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <!-- endinject -->

  <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="<?php echo e(asset('images/favicon.ico')); ?>"
    />

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-confirmation/1.0.5/bootstrap-confirmation.min.js"></script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  window.OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "3cb94275-991b-48b2-8c8d-8ea9b26206c7",
    });
  });
</script> -->

</head>
<body>

<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex justify-content-center">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between w-100">  
          <a class="navbar-brand brand-logo" href="#"><img src="<?php echo e(asset('images/admin-logo.png')); ?>" alt="logo"/></a>
          <button class="navbar-toggler navbar-toggler align-self-center mt-3" type="button" data-toggle="minimize">
            <span class="mdi mdi-sort-variant"></span>
          </button>
        </div>  
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav mr-lg-4 w-100">
          
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          
         
        <?php if(Session::has('user')): ?>
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
            <img src="<?php echo e(asset('images/user-icone.png')); ?>" class="round-border" alt="profile"/>
              <span class="nav-profile-name"><?php echo e(Session::get('user')['name']); ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="/logout">
                <i class="mdi mdi-logout text-primary"></i>
                Logout
              </a>
            </div>
          </li>
          <?php else: ?>
          <li><a href="/">Login</a></li>
          <?php endif; ?>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="/admin">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>


          <!-- <li class="nav-item">
          <a class="nav-link" href="/app">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">App Data</span>
            </a>
          </li> -->

          
          <li class="nav-item">
            <a class="nav-link" href="/ads">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">Ads links</span>
            </a>
          </li>

          <!-- <li class="nav-item">
            <a class="nav-link" href="/imagesdata">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">Hand Data</span>
            </a>
          </li> -->

          

          <li class="nav-item">
            <a class="nav-link" href="/pushnotification">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">Push Notification</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="/autonotification">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">Auto Notification</span>
            </a>
          </li>

          <!-- <li class="nav-item">
            <a class="nav-link" href="/application">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">More App</span>
            </a>
          </li> -->

          <li class="nav-item">
            <a class="nav-link" href="/profile/<?php echo e(Session::get('user')['id']); ?>">
              <i class="mdi mdi-key-variant menu-icon"></i>
              <span class="menu-title">Change Password</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="/logout">
              <i class="mdi mdi-logout menu-icon"></i>
              <span class="menu-title">Logout</span>
            </a>
          </li>
          
        </ul>
      </nav>
  
      
<?php echo $__env->yieldContent('content'); ?>

<!-- <script type="text/javascript">
$('#search').on('keyup',function(){
$value=$(this).val();
$.ajax({
type : 'get',
url : '/search',
data:{'search':$value},
success:function(data){
$('tbody').html(data);
}
});
})
</script> -->

<script type="text/javascript">
$.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>


<script type="text/javascript">
    $(document).ready(function () {
        $('#master').on('click', function(e) {
         if($(this).is(':checked',true))  
         {
            $(".sub_chk").prop('checked', true);  
         } else {  
            $(".sub_chk").prop('checked',false);  
         }  
        });
        $('.delete_all').on('click', function(e) {
            var allVals = [];  
            $(".sub_chk:checked").each(function() {  
                allVals.push($(this).attr('data-id'));
            });  
            if(allVals.length <=0)  
            {  
                alert("Please select row.");  
            }  else {  
                var check = confirm("Are you sure you want to delete this row?");  
                if(check == true){  
                    var join_selected_values = allVals.join(","); 
                    $.ajax({
                        url: $(this).data('url'),
                        type: 'DELETE',
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                        data: 'ids='+join_selected_values,
                        success: function (data) {
                            if (data['success']) {
                                $(".sub_chk:checked").each(function() {  
                                    $(this).parents("tr").remove();
                                });
                                // alert(data['success']);
                            } else if (data['error']) {
                                alert(data['error']);
                            } else {
                                alert('Whoops Something went wrong!!');
                            }
                        },
                        error: function (data) {
                            alert(data.responseText);
                        }
                    });
                  $.each(allVals, function( index, value ) {
                      $('table tr').filter("[data-row-id='" + value + "']").remove();
                  });
                }  
            }  
        });
        $('[data-toggle=confirmation]').confirmation({
            rootSelector: '[data-toggle=confirmation]',
            onConfirm: function (event, element) {
                element.trigger('confirm');
            }
        });
        $(document).on('confirm', function (e) {
            var ele = e.target;
            e.preventDefault();
            $.ajax({
                url: ele.href,
                type: 'DELETE',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success: function (data) {
                    if (data['success']) {
                        $("#" + data['tr']).slideUp("slow");
                        // alert(data['success']);
                    } else if (data['error']) {
                        alert(data['error']);
                    } else {
                        alert('Whoops Something went wrong!!');
                    }
                },
                error: function (data) {
                    alert(data.responseText);
                }
            });
            return false;
        });
    });
</script>

  <!-- plugins:js -->
  <script src="<?php echo e(asset('vendors/base/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo e(asset('vendors/chart.js/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('js/template.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(asset('js/data-table.js')); ?>"></script>
  <script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>
  <!-- End custom js for this page-->

  <script src="<?php echo e(asset('js/jquery.cookie.js')); ?>" type="text/javascript"></script>
</body>

</html>

<?php /**PATH E:\API\ADMIN_PANEL_FINAL\resources\views/layouts/admin.blade.php ENDPATH**/ ?>