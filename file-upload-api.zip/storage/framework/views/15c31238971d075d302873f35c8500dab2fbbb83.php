

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        App List
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">App</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
            </div>



<div class="row">
<div class="col-md-6">

<a href="<?php echo e(route('admin.appdata.create')); ?>" class="bg-primary text-white text-decoration-none" style="padding:12px 12px;margin-left:20px"><i class="mdi mdi-plus mdi-48px;"></i>&nbsp;ADD</a>

</div>
<div class="col-md-6">
 
<!-- <form type="get" action="<?php echo e(url('/searchappdata')); ?>">
        <div>
            <input type="text" name="query" class="border border-dark" placeholder="Search package name">
                <button type="submit" class="fa fa-search bg-primary text-white"></button>
        </div>
  </form> -->

  <!-- <form action="<?php echo e(url('/searchappdata')); ?>" method="get" id="myForm">  

  <input type="text" name="query" class="border border-dark" placeholder="Search package name">

</form> -->






<div class="row">
<div class="col-md-8">
<!-- <form action="" method="POST" class="w-100">
    <div class="input-group mb-3">
      <input type="text" class="form-control" placeholder="Search package / app name" id="search">
  </div>
</form> -->

<form action="/searchapppackage" method="post">
  <?php echo csrf_field(); ?>
<input type="text" name="query" class="border border-dark" placeholder="Search package / app name">
</form>


</div>
<div class="col-md-4">
<a href="/appdata" class="btn btn-primary">Clear</a>
</div>

</div>


</div>
</div>

<!-- <button style="padding:10px 10px;" class="btn btn-danger mb-1 text-white delete_all" data-url="<?php echo e(url('deleteappdataAll')); ?>">Delete</button> -->

            <!-- /.box-header -->

            
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
              
                  <th>App id</th>
                  <th>App Name</th>
                  <th>Package Name</th>
                  <th>Privacy Policy</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                


                </tbody>
              </table>


        <div class="row mt-4">

          <div class="col-sm-12 col-sm-offset-5" style="display:flex;justify-content:center;">

         

          </div>
      </div>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.1.1.min.js">
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
// <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script>
$('#search').on('keyup', function(){
    search();
});
search();
function search(){
     var keyword = $('#search').val();


     $.ajax(
        {
            url: "/employee/search",
            type: 'post',
            data: {
              _token: $('meta[name="csrf-token"]').attr('content'),
                keyword:keyword
            },
            success: function(data){
                  table_post_row(data);
                console.log(data);
            },
        });   
}

function table_post_row(res){
let htmlView = '';
if(res.employees.length <= 0){
    htmlView+= `
       <tr>
          <td colspan="4">No data.</td>
      </tr>`;
}
for(let i = 0; i < res.employees.length; i++){
    htmlView += `
        <tr>
        <td>`+ res.employees[i].id +`</td>
           <td>`+ res.employees[i].app_name +`</td>
              <td>`+res.employees[i].package_name+`</td>
               <td>`+res.employees[i].privacy+`</td>
               <td><a href="<?php echo e(url('admin/appdata/edit/`+res.employees[i].id+`')); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:#0275d8;padding:8px;border-radius:200px;"></i></a></td>
               <td><a href="<?php echo e(url('admin/appdata/destroy/`+res.employees[i].id+`')); ?>"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:red;padding:8px;border-radius:200px;"></i></a></td>
        </tr>`;
}
     $('tbody').html(htmlView);
}
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/appdata/index.blade.php ENDPATH**/ ?>