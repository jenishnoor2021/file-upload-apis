

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-4">
            <div class="card border border-primary">
                <div class="card-header bg-primary text-white"><h5 class="mt-2">List of App</h5></div>
                
                <div class="card-body">

<a href="<?php echo e(route('admin.application.create')); ?>" class="bg-primary text-white text-decoration-none" style="padding:8px 8px;"><i class="mdi mdi-plus mdi-48px;"></i>&nbsp;ADD</a>

<button style="padding:10px 10px;" class="btn btn-danger mb-1 text-white delete_all" data-url="<?php echo e(url('myapplicationsDeleteAll')); ?>">Delete</button>

<form type="get" action="<?php echo e(url('/searchapplication')); ?>" class="float-end mt-1">
    <div>
        <input type="text" name="query" class="border border-dark p-1" placeholder="Search">
            <button type="submit" class="mdi mdi-search-web bg-primary text-white p-1"></button>
    </div>
</form>


<table class="table border border-dark mt-4 table-striped">
          <thead style="text-align:center;">
              <tr>              
                  <th width="3%" class="border border-dark"><input type="checkbox" id="master"></th>  
                  <th width="5%" class="border border-dark">Cat Id</th>                 
                  <th width="10%" class="border border-dark">Category</th>
                  <th width="5%" class="border border-dark">App Id</th>
                  <th width="10%" class="border border-dark">App_name</th>
                  <th width="7%" class="border border-dark">image</th>
                  <th width="25%" class="border border-dark">App_URL</th>
                  <th width="5%" class="border border-dark">Edit</th>
                  <th width="5%" class="border border-dark">Delete</th>
              </tr>
              </thead>
              <tbody style="text-align:center;">

              <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr id="tr_<?php echo e($application->id); ?>"> 
                  <td style="text-align:center;"><input type="checkbox" class="sub_chk" data-id="<?php echo e($application->id); ?>"></td>
                  <td class="border border-dark"><?php echo e($application->category); ?></td>
                  <td class="border border-dark"><?php echo e($application->category == 1 ? 'small app' : 'genuine'); ?></td>
                  <td class="border border-dark"><?php echo e($application->id); ?></td>
                  <td class="border border-dark"><?php echo e($application->application_name); ?></td>
                  <td class="border border-dark"> <img height="50" src="<?php echo e($application->file ? $application->file : 'https://eitrawmaterials.eu/wp-content/uploads/2016/09/person-icon.png'); ?>" alt="" ></td>
                  <td class="border border-dark"><?php echo e($application->application_url); ?></td>

                  <td class="border border-dark" style="text-align:center;"><a href="<?php echo e(route('admin.application.edit', ['id' => $application->id] )); ?>"><i class='mdi mdi-account-edit' style="color:white;font-size:20px;background-color:#0275d8;padding:5px;"></i></a></td>
                  <td style="text-align:center;">
                      <?php echo Form::open(['method'=>'GET', 'action'=> ['AdminApplicationAddController@destroy', $application->id]]); ?>


                      
                          <?php echo Form::button('<i class="mdi mdi-delete" style="color:white;font-size:20px;background-color:red;padding:5px;"></i>', ['class'=>'border border-white','role' => 'button', 'type' => 'submit']); ?>

                      
                      <?php echo Form::close(); ?>  
                  </td>
              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              


          </tbody>
          </table>

      <div class="row mt-4">

          <div class="col-sm-12 col-sm-offset-5" style="display:flex;justify-content:center;">

          <?php echo e($applications->links('pagination::bootstrap-4')); ?>



          </div>
      </div>

              </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster_third\resources\views/admin/application/index.blade.php ENDPATH**/ ?>