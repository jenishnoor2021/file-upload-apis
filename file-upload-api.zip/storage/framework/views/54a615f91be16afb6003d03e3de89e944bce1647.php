

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border border-primary">
                <div class="card-header bg-primary text-white"><h5 class="mt-2">Edit Data</h5></div>

                <div class="card-body">
                  
                  <?php echo Form::model($application, ['method'=>'PATCH', 'action'=> ['AdminApplicationAddController@update', $application->id],'files'=>true]); ?>

                  
                  <input type="hidden" name="last_url" value="<?php echo e(URL::previous()); ?>">

                  <div class="row justify-content-center">

                      <div class="form-group col-md-3">
                          <?php echo Form::label('category', 'Category:'); ?>

                          <?php echo Form::select('category', array('' => 'Choose Category','1' => 'small app', '2' => 'genuine'),null, ['class'=>'form-control border border-dark mb-2 p-3 text-dark','required' => 'required']); ?>

                      </div>

                      <div class="form-group col-md-4">
                          <?php echo Form::label('application_name', 'App Name:'); ?>

                          <?php echo Form::text('application_name',null, ['class'=>'form-control border border-dark mb-2','required' => 'required']); ?>

                      </div>    
              
        
                      <div class="form-group col-md-1">
                        <img height="75" src="<?php echo e($application->file ? $application->file : 'https://eitrawmaterials.eu/wp-content/uploads/2016/09/person-icon.png'); ?>" alt="">
                      </div> 
                      

                      <div class="form-group col-md-4">
                          <?php echo Form::label('file', 'Image:'); ?>

                          <input type="file" name="file" id="file" class="form-control border border-dark mb-2" accept="image/*">
                      </div>
                    </div>
                          
                    <div class="row justify-content-center">  
                  <div class="form-group col-md-12">
                        <?php echo Form::label('application_url', 'Application URL:'); ?>

                        <?php echo Form::text('application_url', null, ['class'=>'form-control border border-dark mb-2','required' => 'required']); ?>

                  </div>
                </div>

                  <div class="row justify-content-center">  
                  <div class="form-group col-md-2">
                      <?php echo Form::submit('Update Data', ['class'=>'btn btn-success text-white mt-3']); ?>

                  </div>
                </div>


                            <?php echo Form::close(); ?>

 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster_third\resources\views/admin/application/edit.blade.php ENDPATH**/ ?>