

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        App Edit
        <!-- <small>Preview</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">App</a></li>
        <li class="active">Edit</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- right column -->
        <div class="col-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Horizontal Form</h3> -->
            </div>
            <!-- /.box-header -->
            <!-- form start -->

  <?php echo Form::model($appname, ['method'=>'PATCH', 'action'=> ['AdminAppdataController@update', $appname->id],'files'=>true,'class'=>'form-horizontal']); ?>


    <?php echo csrf_field(); ?>

              <div class="box-body">
                <div class="form-group">
                  <label for="app_name" class="col-sm-2 control-label">App name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="app_name" id="app_name" value="<?php echo e($appname->app_name); ?>" required>
                  </div>
                </div>

                <div class="form-group">
                  <label for="package_name" class="col-sm-2 control-label">Package Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="package_name" id="package_name" value="<?php echo e($appname->package_name); ?>" required>
                  </div>
                </div>

                <div class="form-group">
                  <label for="privacy" class="col-sm-2 control-label">Privacy Policy</label>
                  <div class="col-sm-10">
                    <input type="text" name="privacy" class="form-control" id="privacy" value="<?php echo e($appname->privacy); ?>">
                  </div>
                </div>
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default">Cancel</button> -->
                <!-- <button type="submit" class="btn btn-info">Sign in</button> -->
                <?php echo Form::submit('Update Data', ['class'=>'btn btn-success text-white mt-1']); ?>

              </div>
              <!-- /.box-footer -->
        <?php echo Form::close(); ?>

          </div>
          <!-- /.box -->
          
         
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/appdata/edit.blade.php ENDPATH**/ ?>