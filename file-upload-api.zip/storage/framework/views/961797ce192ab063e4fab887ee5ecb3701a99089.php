

<?php $__env->startSection('content'); ?>


<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          
          
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card border border-primary">
                <div class="card-body dashboard-tabs p-0">
                  <ul class="nav nav-tabs bg-primary" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link text-white pb-3" id="overview-tab" data-bs-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true"><h3>Dashboard</h3></a>
                    </li>
                  </ul>

            <div class="row m-3">
              
                <div class="col-xl-3 col-md-6 mb-4">
                  <div class="card card-box border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                        <a href="/app" class="text-decoration-none">
                          <div class="row">
                            <div class="col mr-2">
                              <div class="text-xs text-uppercase text-dark">Total App</div>
                              <div class="h5 mb-0 font-weight-bold text-primary mt-2"><h3><?php echo e($totalapp); ?></h3></div>
                            </div>
                            <div class="col-auto bg-primary pt-2 pb-1 pl-4 pr-4">
                              <i class="mdi mdi-format-list-bulleted icon-lg text-white"></i>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              
              
                <div class="col-xl-3 col-md-6 mb-4">
                  <div class="card card-box border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                      <div class="row no-gutters align-items-center">
                      <a href="/ads" class="text-decoration-none">
                      <div class="row">
                        <div class="col mr-2">
                          <div class="text-xs text-uppercase text-dark">Total Ads</div>
                          <div class="h5 mb-0 font-weight-bold text-primary mt-2"><h3><?php echo e($totalads); ?></h3></div>
                        </div>
                        <div class="col-auto bg-primary pt-2 pb-1 pl-4 pr-4">
                          <i class="mdi mdi-format-list-bulleted icon-lg text-white"></i>
                        </div>
                      </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              
            </div>
                  
                    
                  
                </div>
              </div>
            </div>
          </div>
          
          
        
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\API\newaddmaster\resources\views/admin/index.blade.php ENDPATH**/ ?>