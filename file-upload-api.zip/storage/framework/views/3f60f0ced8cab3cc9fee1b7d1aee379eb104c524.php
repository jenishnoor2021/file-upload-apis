

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Change Password
        <!-- <small>Preview</small> -->
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- right column -->
        <div class="col-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <!-- <h3 class="box-title">Horizontal Form</h3> -->
            </div>
            <!-- /.box-header -->
            <!-- form start -->

    <div class="box-body">

            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form class="form-horizontal" method="POST" action="<?php echo e(route('profile.update')); ?>">
                        <?php echo e(csrf_field()); ?>



                        <div class="form-group<?php echo e($errors->has('current-password') ? ' has-error' : ''); ?> row">
                        <label for="new-password" class="col-md-4 control-label">Current Password</label>
                    <div class="col-sm-8">
                        <input id="current-password" type="password" class="form-control border border-dark" name="current-password" required>

                            <?php if($errors->has('current-password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('current-password')); ?></strong>
                                </span>
                            <?php endif; ?>
                    </div>
                </div>


                <div class="form-group<?php echo e($errors->has('new_password') ? ' has-error' : ''); ?> row">
                        <label for="new-password" class="col-md-4 control-label">New Password</label>
                    <div class="col-sm-8">
                        <input id="new-password" type="password" class="form-control border border-dark" name="new-password" required>

                            <?php if($errors->has('new_password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('new_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                        <label for="new-password-confirm" class="col-md-4 control-label">Confirm New Password</label>
                    <div class="col-sm-8">
                        <input id="new-password-confirm" type="password" class="form-control border border-dark" name="new-password_confirmation" required>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-md-12 text-center">
                        <button type="submit" class="btn btn-success text-white">
                            Change Password
                        </button>
                    </div>
                </div>
            </form>



 
     
    
          </div>
          <!-- /.box -->
          
         
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin_panel_template\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>