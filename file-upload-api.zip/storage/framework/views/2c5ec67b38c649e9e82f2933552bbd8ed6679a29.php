

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        App List
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">App</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
            </div>

<div class="row">
<div class="col-md-9">

<a href="<?php echo e(route('admin.appdata.create')); ?>" class="bg-primary text-white text-decoration-none" style="padding:12px 12px;margin-left:20px"><i class="mdi mdi-plus mdi-48px;"></i>&nbsp;ADD</a>

</div>
<div class="col-md-2">
<!-- <form type="get" action="<?php echo e(url('/searchappdata')); ?>">
        <div>
            <input type="text" name="query" class="border border-dark" placeholder="Search package name">
                <button type="submit" class="fa fa-search bg-primary text-white"></button>
        </div>
  </form> -->


<form action="/searchapppackage" method="post">
  <?php echo csrf_field(); ?>
<input type="text" name="query" class="border border-dark" placeholder="Search package / app name">
</form>
</div>

<div class="col-md-1">

  <a href="/appdata" class="btn btn-primary">Clear</a>

</div>

</div>
</div>


<!-- <button style="padding:10px 10px;" class="btn btn-danger mb-1 text-white delete_all" data-url="<?php echo e(url('deleteappdataAll')); ?>">Delete</button> -->

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <!-- <th width="50px"><input type="checkbox" id="master"></th>                -->
                  <th>App id</th>
                  <th>App Name</th>
                  <th>Package Name</th>
                  <th>Privacy Policy</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                
                <?php if($appnames->count()): ?>
              <?php $__currentLoopData = $appnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr id="tr_<?php echo e($appname->id); ?>"> 
              <!-- <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($appname->id); ?>"></td> -->
                      <td class="border border-dark"><?php echo e($appname->id); ?></td>
                      <td class="border border-dark"><?php echo e($appname->app_name); ?></td>
                      <td class="border border-dark"><?php echo e($appname->package_name); ?></td>
                      <td class="border border-dark"><?php echo e($appname->privacy); ?></td>
                      <td class="border border-dark"><a href="<?php echo e(route('admin.appdata.edit', $appname->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:#0275d8;padding:8px;border-radius:200px;"></i></a></td>

                      <td class="border border-dark"><a href="<?php echo e(route('admin.appdata.destroy', $appname->id)); ?>"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:red;padding:8px;border-radius:200px;"></i></a></td>
                          
                  </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

                </tbody>
              </table>

              <div class="row mt-4">

<div class="col-sm-12 col-sm-offset-5" style="display:flex;justify-content:center;">

<?php echo e($appnames->links('pagination::bootstrap-4')); ?>


</div>
</div>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vrushabhsir-all\Admin_Panel_v\resources\views/admin/appdata/search.blade.php ENDPATH**/ ?>